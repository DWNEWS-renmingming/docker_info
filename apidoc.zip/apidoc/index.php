<?php
#apidoc -i apidoc/ -o doc/
    /**
    * @api {get} /v1/comment.php  敏感词评论检测
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Comment
    * @apiDescription Eovobo系统敏感词评论检测
    * @apiGroup Comment
    *
    * @apiParam {String} action  选择方法：textModeration （敏感词）
    * @apiParam {String} content 文字内容
    * @apiExample 请求样例:
    * mydata.eovobo.com/v1/comment.php?action=textModeration&content=好孩子
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *     "error": 0,
    *     "message": "检测评论内容是否合法",
    *     "EvilFlag": 0
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 1,
    *    "message": "CONTENT_REQUIRED"
    *}
    */

    /**
    * @api {get} /v1/comment.php 自动翻译
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Comment
    * @apiDescription Eovobo系统自动翻译
    * @apiGroup Comment
    *
    * @apiParam {String} action  选择方法：TextTranslate （自动翻译）
    * @apiParam {String} content 文字内容
    * @apiExample 请求样例:
    * mydata.eovobo.com/v1/comment.php?action=TextTranslate&content=你好
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *    "error": 0,
    *    "message": "自动识别语言翻译英文内容(机器翻译)",
    *    "TargetText": "Hello"
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "CONTENT_REQUIRED"
    *}
    */
    ##############################################

     /**
    * @api {$_FILES} /v1/dynamic.php 动态发布上传图片
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Dynamic
    * @apiDescription Eovobo系统 敏感图片处理
    * @apiGroup Dynamic
    *
    * @apiParam {String} action  选择方法：uploadFile（上传图片）
    * @apiParam {String} file    图片字段
    * @apiExample 请求样例:
    * mydata.eovobo.com/v1/dynamic.php?action=uploadFile
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *    {
    *    "error": 0,
    *    "message": "上传成功",
    *    "file_url": "https://mydata.eovobo.com/data/user_dynamic/2020_09_10/d6e654d9987e86c1bf102524666ffd01.mp4",
    *    "type": "Video",
    *    "fid": "8"
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "CONTENT_REQUIRED"
    *}
    */

     /**
    * @api {get} /v1/dynamic.php  删除临时动态
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Dynamic
    * @apiDescription Eovobo系统 敏感图片处理
    * @apiGroup Dynamic
    *
    * @apiParam {String} action  选择方法：deleteUpload（删除临时动态图片）
    * @apiParam {Int} info[fid] 5
    * @apiExample 请求样例:
    * https://mydata.eovobo.com/v1/dynamic.php?action=deleteUpload&info[fid]=5
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *    "error": 0,
    *    "message": "ok",
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "CONTENT_REQUIRED"
    *}
    */

     /**
    * @api {get} /v1/dynamic.php  个人中心删除动态
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Dynamic
    * @apiDescription Eovobo系统 删除mydata服务图片
    * @apiGroup Dynamic
    *
    * @apiParam {String} action  选择方法：deleteNews（个人中心删除动态）
    * @apiParam {Int}   info[id] 参数
    * @apiExample 请求样例:
    * https://mydata.eovobo.com/v1/dynamic.php?action=deleteNews&info[id]=5
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *    "error": 0,
    *    "message": "ok"
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "CONTENT_REQUIRED"
    *}
    */


    ####################直播中英文翻译translation.php##########################

    /**
    * @api {get} /v1/translation.php  直播翻译添加
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Translation
    * @apiDescription Eovobo系统 直播翻译
    * @apiGroup Translation
    *
    * @apiParam {Int}     rid  直播间ID
    * @apiParam {String}  operation   add|list （这两类 添加语言翻译 接口  operation 选择 add）
    * @apiParam {String}  language    en|zh	（语言类型）
    * @apiParam {String}  content     语言内容
    * @apiExample 请求样例:
    * https://mydata.eovobo.com/v1/translation.php?rid=999&operation=add&language=en&content=hello1
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *    "error": 0,
    *    "message": "中文翻译添加成功"（英文翻译添加成功）
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "操作型不能为空"
    *}
    */

    /**
    * @api {get} /v1/translation.php  直播翻译列表
    * @apiVersion 1.0.0
    * @apiPermission Guest
    * @apiName Translation
    * @apiDescription Eovobo系统 直播翻译
    * @apiGroup Translation
    *
    * @apiParam {Int}     rid  直播间ID
    * @apiParam {String}  operation   list （这两类 获取语言翻译列表 接口  operation 选择 list）
    * @apiParam {String}  language    en|zh	（语言类型）
    * @apiParam {Int}     min     当前数据下标
    * @apiExample 请求样例:
    * http://mydata.eovobo.com/v1/translation.php?rid=19&operation=list&language=zh&min=2
    * @apiSuccess      {String} message 信息.
    * @apiSuccess      {Int}    error 0 代表无错误 400代表有错误
    * @apiSuccessExample Success-Response:{json}
    *{
    *"error": 0,
    *"message": "获取本场直播的语音文字",
    *    "result": {
    *        "list": [
    *            "hello",
    *            "hello",
    *            "hello1",
    *            "hello1",
    *            "hello1",
    *            "hello1",
    *            "hello1"
    *        ],
    *        "count": 7,
    *        "status": 0
    *    }
    *}
    * @apiErrorExample  Error-Response: {json}
    *{
    *    "error": 400,
    *    "message": "操作型不能为空"
    *}
    */
?>